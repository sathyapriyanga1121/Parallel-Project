package com.cap.dao;



import com.cap.bean.BankAccount;

public interface BankDaoInterface {
	 public BankAccount createAccount(BankAccount bankAccount);
	 public int showBalance(Integer accountNumber);
	 public int depositAmount(Integer accountNumber,Integer amount);
	 public int withDraw(Integer accountNumber,Integer amount);
	 public int fundTransfer(Integer accountNumber1,Integer accountNumber2,Integer amount);
	 void printTransactions();
	
}
