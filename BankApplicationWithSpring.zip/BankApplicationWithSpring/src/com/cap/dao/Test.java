package com.cap.dao;

import static org.junit.Assert.*;

public class Test {


	   BankDaoClass dao=new BankDaoClass();
	    
	    @org.junit.Test
	    public void test1(){
	    	int deposit=500;
	        int balance=dao.showBalance(1);
	        int result=dao.depositAmount(1, deposit);
	        int expectedResult=balance+500;
	        assertEquals(expectedResult,result);
	        System.out.println(expectedResult=result);
	    }
	    
	    @org.junit.Test
	    public void test2(){
	    	int withdraw=500;
	        int balance=dao.showBalance(1);
	        int result=dao.withDraw(1, withdraw);
	        int expectedResult=balance-500;
	        assertEquals(expectedResult,result);
	        System.out.println(expectedResult+"="+result);
	    }
	    
	    @org.junit.Test
	    public void test3(){
	    	int fund=500;
	        int balance=dao.showBalance(1);
	        int result=dao.fundTransfer(1,3,fund);
	        int expectedResult=balance-500;
	        assertEquals(expectedResult,result);
	        System.out.println(expectedResult=result);
	    }
	    
	    

}
