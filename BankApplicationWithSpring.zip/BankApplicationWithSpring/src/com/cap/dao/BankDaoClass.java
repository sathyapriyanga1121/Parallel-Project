package com.cap.dao;


//import java.sql.Statement;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.bean.BankAccount;
import com.cap.bean.BankTransaction;
@Repository
public class BankDaoClass implements BankDaoInterface  {

	@PersistenceContext
	private EntityManager entityManager;

	
	
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional
	public BankAccount createAccount(BankAccount bankAccount) {
		entityManager.persist(bankAccount);
		return bankAccount;
	}

	@Override
	public int showBalance(Integer accountNumber) {
		BankAccount account = entityManager.find(BankAccount.class, accountNumber);
		return account.getBalance();
	}
@Transactional
	@Override
	public int depositAmount(Integer accountNumber, Integer amount) {
		BankAccount account = entityManager.find(BankAccount.class, accountNumber);
		int oldbalance=account.getBalance();
		int newBalance=oldbalance+amount;
		account.setBalance(newBalance);
		entityManager.merge(account);
		
		BankTransaction bt=new BankTransaction();
		bt.setFromAccount(accountNumber);
		bt.setOldBalance(oldbalance);
		bt.setNewBalance(newBalance);
		bt.setTransactionType("deposit");
		entityManager.persist(bt);
		
		
		
		return newBalance;
	}
@Transactional
	@Override
	public int withDraw(Integer accountNumber, Integer amount) {
		BankAccount account = entityManager.find(BankAccount.class, accountNumber);
		int oldbalance=account.getBalance();
		int newBalance=oldbalance-amount;
		account.setBalance(newBalance);
		entityManager.merge(account);
		
		
		BankTransaction bt=new BankTransaction();
		bt.setFromAccount(accountNumber);
		bt.setOldBalance(oldbalance);
		bt.setNewBalance(newBalance);
		bt.setTransactionType("withdraw");
		entityManager.persist(bt);
		return newBalance;
	}
@Transactional
	@Override
	public int fundTransfer(Integer accountNumber1, Integer accountNumber2, Integer amount) {
		BankAccount account = entityManager.find(BankAccount.class, accountNumber1);
		int oldbalance=account.getBalance();
		int newBalance=oldbalance-amount;
		account.setBalance(newBalance);
		entityManager.merge(account);
		
		BankTransaction bt=new BankTransaction();
		bt.setFromAccount(accountNumber1);
		bt.setToAccount(accountNumber2);
		bt.setOldBalance(oldbalance);
		bt.setNewBalance(newBalance);
		bt.setTransactionType("debited");
		entityManager.persist(bt);
		
		BankAccount account1 = entityManager.find(BankAccount.class, accountNumber2);
		int oldbalance1=account1.getBalance();
		int newBalance1=oldbalance+amount;
		account1.setBalance(newBalance1);
		entityManager.merge(account1);
		
		
		BankTransaction bt1=new BankTransaction();
		bt1.setFromAccount(accountNumber1);
		bt1.setToAccount(accountNumber2);
		bt1.setOldBalance(oldbalance1);
		bt1.setNewBalance(newBalance1);
		bt1.setTransactionType("credited");
		entityManager.persist(bt1);
		
		return newBalance;
	}

	@Override
	public void printTransactions() {
		TypedQuery<BankTransaction> q2=entityManager.createQuery("select c from BankTransaction c",BankTransaction.class);
		List<BankTransaction> l1=q2.getResultList();
		for(BankTransaction em1:l1)
		{
			System.out.println(em1.getTransactionID()+"  "+em1.getFromAccount()+"  "+em1.getToAccount()+" "+em1.getOldBalance()+" "+em1.getNewBalance()+" "+em1.getTransactionType());
			
		}
		
	}

	
		
	}
	

	

