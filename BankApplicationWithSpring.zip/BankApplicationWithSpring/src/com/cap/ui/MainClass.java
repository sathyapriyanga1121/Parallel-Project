package com.cap.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cap.bean.BankAccount;
import com.cap.exceptions.AccountNumberNotFoundException;
import com.cap.service.BankServiceInterface;
import com.cap.service.BankServiceclass;

public class MainClass {
	static BankAccount bankAccount = new BankAccount();
	static Scanner scanner = new Scanner(System.in);


	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		BankServiceInterface bankServiceInterface=context.getBean("bankService",BankServiceclass.class);
		while (true) {
			System.out.println("1.create new account");
			System.out.println("2.show balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");

			int option = scanner.nextInt();
			switch (option) {
			case 1: 																				// gets input from the user and creates account

				String name;
				Boolean isName;
				do 																					// name validation by calling service interface
				{
					System.out.println("Enter your name:");
					name = scanner.next();
					isName = bankServiceInterface.nameValidation(name);
					if (!isName) {
						System.out.println("only alphabets are allowed ");
						System.out.println("first letter must be in uppercase");
					}
				} while (!isName);

				System.out.println("Enter branch name:");
				String branch = scanner.next();
				System.out.println("Enter amount:");
				int balance = scanner.nextInt();
				System.out.println("Enter account type:");
				String accountType = scanner.next();
				long mobileNumber;
				Boolean isNumber;																	//validates mobile number by calling service interface number validation method
				do {
					System.out.println("Enter 10 digit mobile number:");
					mobileNumber = scanner.nextLong();
					isNumber = bankServiceInterface.numberValidation(mobileNumber);
					if (!isNumber) {
						System.out.println("Enter valid mobile number");

					}
				} while (!isNumber);
				bankAccount.setAccounteeName(name);
				bankAccount.setAccountType(accountType);
				bankAccount.setBalance(balance);
				bankAccount.setMobileNumber(mobileNumber);
				bankAccount.setBranch(branch);
				BankAccount ba = bankServiceInterface.createAccount(bankAccount);
				System.out.println("Account created");
				System.out.println("Your account number is:" + bankAccount.getAccountNumber());
				System.out.println("your account details are:" + ba);
				System.out.println("**************************************************");
				break;

			case 2: 																				// shows available balance
				try {
					System.out.println("Enter your account number:");
					int accNo = scanner.nextInt();

					System.out.println("Available balance is:" + bankServiceInterface.showBalance(accNo));
					System.out.println("****************************************************");
				} catch (AccountNumberNotFoundException ae) {										//displays error message if the given account number is not available
					ae.printStackTrace();
				}

				break;

			case 3: 																				// amount deposited and total balance is calculated
				try {
					System.out.println("Enter your account number:");
					int accNo1 = scanner.nextInt();
					System.out.println("Enter the amount to be deposited:");
					int amount = scanner.nextInt();
					System.out.println("Amount deposited....");
					bankAccount.setBalance(bankServiceInterface.depositAmount(accNo1, amount));
					System.out.println("Your current balance is:" + bankAccount.getBalance());
					System.out.println("****************************************************");
				} catch (AccountNumberNotFoundException ae) {										//displays error message if the given account number is not available
					
					ae.printStackTrace();
				}
				break;

			case 4:																					// amount withdrawn from one account and the remaining balance is calculated
				try {
					System.out.println("Enter account number:");
					int accNo2 = scanner.nextInt();
					System.out.println("Enter the amount to be withdrawn:");
					int amount1 = scanner.nextInt();
					bankAccount.setBalance(bankServiceInterface.withDraw(accNo2, amount1));
					System.out.println("your current balance is:" + bankAccount.getBalance());
					System.out.println("****************************************************");
				} catch (AccountNumberNotFoundException ae) {
					ae.printStackTrace();
				}
				break;

			case 5: 																				// amount transfered from one account to another account and the remaining balance is shown from senders account
				try {
					System.out.println("enter senders account number:");
					int senderAccount = scanner.nextInt();
					System.out.println("enter recievers account number:");
					int recieversAccount = scanner.nextInt();
					System.out.println("enter the amount to be transferred: ");
					int amount2 = scanner.nextInt();
					System.out.println(bankServiceInterface.fundTransfer(senderAccount, recieversAccount, amount2)
							+ " is your current balance....");
					System.out.println("****************************************************");
				} catch (AccountNumberNotFoundException ae) {										//gives error message if the given account number is not found
					ae.printStackTrace();
				}
				break;

			case 6: 																				// transaction statement is printed
				System.out.println("transactions");

				
			
					bankServiceInterface.printTransactions();
				
				System.out.println("****************************************************");
				break;

			case 7: 																				// exits the process

				System.out.println("Thank you");
				System.out.println("****************************************************");
				System.exit(0);
			}
		}

	}
}
