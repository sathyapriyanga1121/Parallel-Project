package com.cap.service;

import java.sql.PreparedStatement;
import java.util.List;

import com.cap.bean.BankAccount;
import com.cap.bean.BankTransaction;

public interface BankServiceInterface {
	public Boolean nameValidation(String name);
	
	public Boolean numberValidation(Long number);
	
	public BankAccount createAccount(BankAccount bankAccount);

	public int showBalance(Integer accountNumber);

	public int depositAmount(Integer accountNumber, Integer amount);

	public int withDraw(Integer accountNumber, Integer amount);

	public int fundTransfer(Integer accountNumber1, Integer accountNumber2, Integer amount);

	void printTransactions();
}
