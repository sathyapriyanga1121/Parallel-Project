package com.cap.service;

import java.sql.PreparedStatement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.bean.BankAccount;
import com.cap.bean.BankTransaction;
import com.cap.dao.BankDaoClass;
import com.cap.dao.BankDaoInterface;
@Service("bankService")
public class BankServiceclass implements BankServiceInterface {

	private BankDaoInterface bankDaoInterface;										//object created for dao interface
@Autowired
	public void setBankDaoInterface(BankDaoInterface bankDaoInterface) {
		this.bankDaoInterface = bankDaoInterface;
	}

	@Override
	public int showBalance(Integer accountNumber) {	
		//bankDaoInterface.beginTransaction();//returns available balance
		int balance = bankDaoInterface.showBalance(accountNumber);
		//bankDaoInterface.commitTransaction();
		return balance;
	}

	@Override
	public BankAccount createAccount(BankAccount bankAccount) {										//bank account details are sent to dao and returns the bank details
	
		BankAccount ba= bankDaoInterface.createAccount(bankAccount);
	
		return ba;
	}

	@Override
	public int depositAmount(Integer accountNumber, Integer amount) {								//adds the deposited amount with old balance and returns new balance
	
		int newBalance =bankDaoInterface.depositAmount(accountNumber, amount);
		
		return newBalance;
	}

	public int withDraw(Integer accountNumber, Integer amount) {	
		//subtracts the given amount from available balance for withdraw
		int newBalance = bankDaoInterface.withDraw(accountNumber, amount);
		
		return newBalance;
	}

	@Override
	public int fundTransfer(Integer accountNumber1, Integer accountNumber2, Integer amount) {	
																	//calls the dao interface for fund transfer
		int transfer = bankDaoInterface.fundTransfer(accountNumber1, accountNumber2, amount);
	
		return transfer;
	}

	@Override
	public void printTransactions() {																	//returns the list of transactions done
		

		 bankDaoInterface.printTransactions();
	}

	public Boolean nameValidation(String customerName) {											//validates the given name
		
		if(customerName.matches("[A-Z][a-zA-Z]*"))													//returns true if the first letter of the name is in upper case and if the name only with alphabets
		{
		  return true;
		}
		else																						//returns false if first letter is not in upper case and if it includes other characters
		{
			return false;
		}
	}

	public Boolean numberValidation(Long number) {													//validates the given number				
		String mobileNumber=Long.toString(number);
		if(mobileNumber.matches("[6-9][0-9]{9}"))													//returns true if the first number starts with 6,7,8,9 and if the number contains 10 digits
		{
			return true;
		
		}
		else																						//returns false if first number starts with 0,1,2,3,4,5 and if it does not have 10 digits 
		{
			return false;
		}
	}

}
