package com.cap.exceptions;

public class AccountNumberNotFoundException extends RuntimeException {


	public AccountNumberNotFoundException(final String message) {
			super(message);

	}

}
