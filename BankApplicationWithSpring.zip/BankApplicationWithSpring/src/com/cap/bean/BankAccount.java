package com.cap.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bankAccount1")
public class BankAccount {
	@Id
	@GeneratedValue
	private int accountNumber;
	private String accounteeName;
	private String branch;
	private int balance;
	private String accountType;
	private Long mobileNumber;

	public int getAccountNumber() {

		

		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccounteeName() {
		return accounteeName;
	}

	public void setAccounteeName(String accounteeName) {
		this.accounteeName = accounteeName;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@Override

	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber + ", accounteeName=" + accounteeName + ", balance="
				+ balance + ", accountType=" + accountType + ", mobileNumber=" + mobileNumber + "]";
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

}
