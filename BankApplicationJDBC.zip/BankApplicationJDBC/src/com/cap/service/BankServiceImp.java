package com.cap.service;

import java.util.HashMap;
import java.util.Map;

import com.bank.bean.BankInfo;
import com.bank.bean.Transaction;
import com.bank.dao.BankDao;
import com.bank.dao.BankDaoImp;

public class BankServiceImp implements BankService {
	BankDao dao=new BankDaoImp();
	Map<Transaction,Long> printTransaction =new HashMap<Transaction,Long>();
	
//implementation for inserting account details	
	@Override
	public void insertDetails(BankInfo bank) {
		dao.insertDetails(bank);
		
	}

//implementation to show details

	@Override
	public long showDetails(long accountNo) {
		
		long bank=dao.showDetails(accountNo);
		return bank;
	}
	
	@Override
	public void printTransactions() {
		dao.printTransactions();
		
	}
	
//implementation to deposit amount
	@Override
	public float depositAmount(long accountNo, float deposit) {
		
		float bank=dao.depositAmount(accountNo,deposit);	
		return bank;
	}
//implementation to withdraw amount	
	@Override
	public float withdrawAmount(long accountNo, float withdrawAmt) {
		
		float bank=dao.withdrawAmount(accountNo,withdrawAmt);		
		return bank;
	}
//implementation to transfer amount
	@Override
	public float transferAmount(long accountNo, long recipientAccNo, float transferAmt) {
		
		float bank=dao.transferAmount(accountNo, recipientAccNo, transferAmt);
		return bank;
	}

	
	
//name validation	 
	public boolean checkName(String name)
	 {
		 if(!name.matches("[A-Z][a-zA-Z]*"))
		 {
			return true;
		 }else
			 return false;
		 
	 }
//mobile number validation
	 public boolean checkNumber(long number)
	 {
		 String mob=Long.toString(number);
		 if(!mob.matches("[6-9][0-9]{9}"))
			return true;	
		 else 
			 return false;
	 }
	 
//account type validation	 
	 public boolean checkAccType(String accType)
	 {
		 if(!accType.equalsIgnoreCase("savings")||accType.equalsIgnoreCase("current"))
			return true;	
		 else 
			 return false;
	 }
//validation for checking transfer amount
	@Override
	public void checkBal(long accountNo, long recipientAccNo, float transferAmt) {
		//float bank=dao.transferAmount(accountNo, recipientAccNo, transferAmt);
		/*float checkBal=bank.getBalance();
		if(checkBal<transferAmt){
			System.out.println("Insufficient Balance");
			System.out.println(bank);}
			else
			{
				System.out.println(bank);
			}
			
	}*/
	}
	//to print transaction details






}
