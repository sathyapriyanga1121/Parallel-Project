package com.bank.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class BankDaoImpTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
