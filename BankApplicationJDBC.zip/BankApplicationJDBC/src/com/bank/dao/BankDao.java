package com.bank.dao;

import com.bank.bean.BankInfo;

public interface BankDao {

	void insertDetails(BankInfo bank);//interface methods for inserting account details
	long showDetails(long accountNo);//interface methods to show details
	float depositAmount(long accountNo, float deposit);//interface methods to deposit amount
	float withdrawAmount(long accountNo, float withdrawAmt);//interface methods to withdraw amount
	float transferAmount(long accountNo, long recipientAccNo, float transferAmt);//interface methods to transfer amount
	void printTransactions();
	
}
