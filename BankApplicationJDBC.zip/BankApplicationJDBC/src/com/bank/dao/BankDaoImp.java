package com.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.bank.bean.BankInfo;
import com.bank.bean.Transaction;
import com.bank.exception.AccountNumberNotFoundException;

public class BankDaoImp implements BankDao{
		Map<Long,BankInfo> bankDetails=new HashMap<Long,BankInfo>();
		Map<Transaction,Long> printTransaction =new HashMap<Transaction,Long>();
		long bal;
//implementation for inserting account details
	@Override
	public void insertDetails(BankInfo bank) {
Connection conn=DBConnect.getConnection();
long acc=0;
try {
	PreparedStatement stat=conn.prepareStatement("insert into bankjdbc values(accnoseq.nextval,?,?,?,?,?)");
	stat.setString(1,bank.getName());
	stat.setFloat(2,bank.getBalance());
	stat.setLong(3,bank.getMobNo());
	stat.setString(4,bank.getAccountType());
	stat.setString(5,bank.getBranch());

    int res=stat.executeUpdate();
    if(res>0)
    {
    	System.out.println("Registered successfully");
	    PreparedStatement sel=conn.prepareStatement("select accnoseq.currval from dual");
	    ResultSet result=sel.executeQuery();
	    result.next();
	    acc=result.getLong(1);
	    bank.setAccountNo(acc);
	 
	    
	    PreparedStatement insert=conn.prepareStatement("insert into transactionjdbc values(?,?,?,?,?,?)");
		insert.setString(1,bank.getName());
		insert.setFloat(2,bank.getBalance());
		insert.setLong(3,bank.getMobNo());
		insert.setString(4,bank.getAccountType());
		insert.setString(5,bank.getBranch());
	    
    }
    else
    {

    	System.out.println("Please provide valid information");
    }
    
    

} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
//return acc;

	}

//implementation to show details
	@Override
	public long showDetails(long accountNo1) {
		
		
		try {
		Connection conn=DBConnect.getConnection();
	
		    PreparedStatement stat=conn.prepareStatement("select balance from bankjdbc where accno=?");
		    stat.setLong(1,accountNo1);
		    ResultSet res=stat.executeQuery();
		    while(res.next()) {
		        bal=res.getLong(1);
		    }
		}
		    
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bal ;
		
	}
	
//implementation to deposit amount
	@Override
	public float depositAmount(long accountNo, float deposit) 
	{
		
		long bal=0;
		float amt=0;
		
		try {
		Connection conn=DBConnect.getConnection();
	
		    PreparedStatement stat=conn.prepareStatement("select balance from bankjdbc where accno=?");
		    stat.setLong(1,accountNo);
		    ResultSet res=stat.executeQuery();
		    while(res.next())
		    {
		    	bal=res.getLong(1);
		    	amt=bal+deposit;
		    	PreparedStatement stat1=conn.prepareStatement("update bankjdbc set balance=? where accno=?");
		    	stat1.setFloat(1, amt);
		    	stat1.setLong(2,accountNo);
		    	int res1=stat1.executeUpdate();
		    	if(res1>0)
	            {
	                
	                PreparedStatement stat2=conn.prepareStatement("insert into transactionjdbc values(transactions.nextval,?,?,?,?,?)");
	                stat2.setLong(1, accountNo);
	                stat2.setLong(2, 0);
	                stat2.setFloat(3, bal);
	                stat2.setFloat(4, amt);
	                stat2.setString(5, "Deposit");
					int result3=stat2.executeUpdate();
	                
	            }
		
		    }
		  
		   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return amt;
	}
	
//implementation to withdraw amount	
	public float withdrawAmount(long accountNo, float withdrawAmt) {
		long bal=0;
		float amt=0;
		
		try {
		Connection conn=DBConnect.getConnection();
	
		    PreparedStatement stat=conn.prepareStatement("select balance from bankjdbc where accno=? ");
		    stat.setLong(1,accountNo);
		    ResultSet res=stat.executeQuery();
		    while(res.next())
		    {
		    	bal=res.getLong(1);
		    	amt=bal-withdrawAmt;
		    	PreparedStatement stat1=conn.prepareStatement("update bankjdbc set balance=? where accno=?");
		    	stat1.setFloat(1, amt);
		    	stat1.setLong(2,accountNo);
		    	int res1=stat1.executeUpdate();
		    	 if(res1>0)
		            {
		                
		                PreparedStatement stat2=conn.prepareStatement("insert into transactionjdbc values(transactions.nextval,?,?,?,?,?)");
		                stat2.setLong(1, accountNo);
		                stat2.setLong(2, 0);
		                stat2.setFloat(3, bal);
		                stat2.setFloat(4, amt);
		                stat2.setString(5, "Withdraw");
						int result3=stat2.executeUpdate();
		                
		            }
		    
		    }
		   
		   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return amt;
	}
		
	

//implementation to transfer amount
	@Override
	public float transferAmount(long accountNo, long recipientAccNo, float transferAmt) {
		long bal=0;
		float amt=0;
		long wbal=0;
		float wamt=0;
		
		try {
		Connection conn=DBConnect.getConnection();
	
		    PreparedStatement stat=conn.prepareStatement("select balance from bankjdbc where accno=? ");
		    stat.setLong(1,accountNo);
		    ResultSet res=stat.executeQuery();
		    while(res.next())
		    {
		    	bal=res.getLong(1);
		    	amt=bal-transferAmt;
		    	PreparedStatement stat1=conn.prepareStatement("update bankjdbc set balance=? where accno=?");
		    	stat1.setFloat(1, amt);
		    	stat1.setLong(2,accountNo);
				int res1=stat1.executeUpdate();
		    	
		    	
		    	PreparedStatement wstat=conn.prepareStatement("select balance from bankjdbc where accno=? ");
			    wstat.setLong(1,recipientAccNo);
			    ResultSet wres=wstat.executeQuery();
			    while(wres.next())
			    {
			    	wbal=wres.getLong(1);
			    	wamt=wbal+transferAmt;
			    	PreparedStatement wstat1=conn.prepareStatement("update bankjdbc set balance=? where accno=?");
			    	wstat1.setFloat(1, wamt);
			    	wstat1.setLong(2,recipientAccNo);
			    	int res2=wstat1.executeUpdate();
			    	  if(res2>0)
			            {
			                
			                PreparedStatement stat2=conn.prepareStatement("insert into transactionjdbc values(transactions.nextval,?,?,?,?,?)");
			                stat2.setLong(1, accountNo);
			                stat2.setLong(2, recipientAccNo);
			                stat2.setFloat(3, bal);
			                stat2.setFloat(4, amt);
			                stat2.setString(5, "fund transfer");
							int result3=stat2.executeUpdate();
			                
			            }
	
		    }
			    }
		   
		}
		
			    catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return amt;
	}
	

	//to print transaction details
    @Override
 public void printTransactions()  {
        
      Transaction trans=new Transaction();    
        PreparedStatement stmt;
        try {
    		Connection conn=DBConnect.getConnection();

             stmt=conn.prepareStatement("select * from transactionjdbc"); // data inputs are got from transaction table
            ResultSet s= stmt.executeQuery();
            while(s.next())
            {
            int id=s.getInt(1);
            int fromAcc=s.getInt(2);
            int toAcc=s.getInt(3);
            int oldBal=s.getInt(4);
            int newBal=s.getInt(5);
            String type=s.getString(6);
            
    // the values in result set are set to bank object
            trans.setTransactionId(id);
            trans.setTransactionAccount(fromAcc);
            trans.setToAccount(toAcc);
            trans.setOldBalance(oldBal);
            trans.setNewBalance(newBal);
            trans.setTransactionType(type);
            System.out.println("========================================");
            System.out.println(trans);
            System.out.println("========================================");

        
            }
        } 
        
        catch (SQLException e) {
            
            e.printStackTrace();
        }
        
    }

 

    
}
   



