
package com.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.bank.bean.BankInfo;
import com.bank.exception.AccountNumberNotFoundException;
import com.cap.service.BankService;
import com.cap.service.BankServiceImp;

public class BankApplication {
	static BankService service = new BankServiceImp();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		while (true) {
			System.out.println("****************************************");
			System.out.println("	 Bank Application");
			System.out.println("****************************************");
			System.out.println("1.Create Account");
			System.out.println("2.Show Account");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");

			System.out.println("Select any option to continue..");
			int option = scanner.nextInt();
			switch (option) {

			case 1: {
				
//Name Validation
				
				try {
					boolean isOkName = false;
					String name = null;
					do {
						System.out.println("Enter your name: ");
						name = scanner.next();
						isOkName = service.checkName(name);
//User friendly suggestion		
						if (isOkName) {
							System.out.println("First Letter of your name must be capital.\n"
									+ "Only characters are allowed.\nDon't enter any special characters.");
						}
					} while (isOkName);

					
//Number Validation	
					boolean isOkNum = false;
					long mobNo = 0;

					do {
						System.out.println("Enter your contact number: ");
						mobNo = scanner.nextLong();
						isOkNum = service.checkNumber(mobNo);
						
//User friendly suggestion
						if (isOkNum) {
							System.out.println("Enter the valid mobile number\n");
						}
					} while (isOkNum);

					
//Account type validation		
					boolean isOkAcctype = false;
					String accountType = null;

					do {
						System.out.println("Enter your account type: ");
						accountType = scanner.next();
						isOkAcctype = service.checkAccType(accountType);
//User friendly suggestion
						if (isOkAcctype) {
							System.out.println("Account type must be either Current or Savings\n");
						}
					} while (isOkAcctype);

					System.out.println("Enter your branch name:  ");
					String branch = scanner.next();
					System.out.println("Enter the opening balance: ");
					float balance = scanner.nextFloat();
					
//inputs added to bank object
					BankInfo bank = new BankInfo();
					bank.setName(name);
					bank.setMobNo(mobNo);
					bank.setAccountType(accountType);
					bank.setBranch(branch);
					bank.setBalance(balance);

					service.insertDetails(bank);
					System.out.println("********************************************************");
					System.out.println("  Account created successfully");
					System.out.println("********************************************************");
					System.out.println("Your generated account Number.." + bank.getAccountNo());
					System.out.println("********************************************************");
				}
//Exception thrown
				catch (InputMismatchException ae) {
					System.out.println("Enter valid input for the given fields");
				}

				break;
			}

			case 2:

			{
				try {

					System.out.println("Enter Your Account number: ");
					long accountNo = scanner.nextLong();

//Account type validation
					boolean isOkAcctype = false;
					String accountType = null;

					do {
						System.out.println("Enter your account type: ");
						accountType = scanner.next();
						isOkAcctype = service.checkAccType(accountType);
//User friendly suggestion
						if (isOkAcctype) {
							System.out.println("Account type must be either Current or Savings\n");
						}
					} while (isOkAcctype);

//details are got from map through service object
					long bank = service.showDetails(accountNo);
					System.out.println("***********************************");
					System.out.println("     Your Account details");
					System.out.println("***********************************");
					System.out.println("YOUR UPDATED ACCOUNT DETAILS "+ bank);
					System.out.println("***********************************");
				}
//Exception thrown for invalid account number
				catch (AccountNumberNotFoundException ae) {
					System.out.println("***********************************************");
					System.out.println("  You've entered an incorrect account number");
					System.out.println("***********************************************");
				}
//Exception thrown for different inputs
				catch (InputMismatchException ae) {
					System.out.println("Enter valid input for the given fields");
				}
				break;
			}

			case 3: {

				try {

					System.out.println("Enter Your Account number: ");
					long accountNo = scanner.nextLong();
//Account type validation
					boolean isOkAcctype = false;
					String accountType = null;

					do {
						System.out.println("Enter your account type: ");
						accountType = scanner.next();
						isOkAcctype = service.checkAccType(accountType);
						
//User friendly suggestion
						if (isOkAcctype) {
							System.out.println("Account type must be either Current or Savings\n");
						}
					} while (isOkAcctype);

					System.out.println("Enter the amount to be deposited: ");
					float deposit = scanner.nextFloat();
					
//amount from user sent to map through service map
					float bank = service.depositAmount(accountNo, deposit);
					System.out.println("**********************************");
					System.out.println("  Amount deposited successfully");
					System.out.println("**********************************");
					System.out.println("  YOUR UPDATED ACCOUNT DETAILS " + bank);
					System.out.println("*********************************");
				}
//Exception thrown for invalid account number
				catch (AccountNumberNotFoundException ae) {
					System.out.println("***********************************************");
					System.out.println("  You've entered an incorrect account number");
					System.out.println("***********************************************");
				} 
//Exception thrown for different inputs
				catch (InputMismatchException ae) {
					System.out.println("Enter valid input for the given fields");
				}

				break;
			}

			case 4: {

				try {
					System.out.println("Enter Your Account number: ");
					long accountNo = scanner.nextLong();
					
//Account type validation
					boolean isOkAcctype = false;
					String accountType = null;

					do {
						System.out.println("Enter your account type: ");
						accountType = scanner.next();
						isOkAcctype = service.checkAccType(accountType);
						
//User friendly suggestion
						if (isOkAcctype) {
							System.out.println("Account type must be either Current or Savings\n");
						}
					} while (isOkAcctype);

					System.out.println("Enter the amount to be withdrawn: ");
					float withdrawAmt = scanner.nextFloat();
					
//amount got from user sent to map through service map
					float bank = service.withdrawAmount(accountNo, withdrawAmt);
					
					
					System.out.println("*********************************");
					System.out.println("  Amount withdrawn successfully");
					System.out.println("*********************************");
					System.out.println("YOUR UPDATED ACCOUNT DETAILS:" + bank);
					System.out.println("*********************************");
				}
//Exception thrown for invalid account number
				catch (AccountNumberNotFoundException ae) {
					System.out.println("***********************************************");
					System.out.println("  You've entered an incorrect account number");
					System.out.println("***********************************************");
				} 
//Exception thrown for different inputs
				catch (InputMismatchException ae) {
					System.out.println("Enter valid input for the given fields");
				}

				break;
			}
			

	case 5: {
				try {

					System.out.println("Enter Your Account number: ");
					long accountNo = scanner.nextLong();
					
//Name Validation
					
					boolean isOkName = false;
					String name = null;
					do {
						System.out.println("Enter your name: ");
						name = scanner.next();
						isOkName = service.checkName(name);
				
//User friendly suggestion
						if (isOkName) {
							System.out.println("First Letter of your name must be capital.\n"
									+ "Only characters are allowed.\nDon't enter any special characters.");
						}
					} while (isOkName);
					
					
//Account type Validation
					boolean isOkAcctype = false;
					String accountType = null;

					do {
						System.out.println("Enter your account type: ");
						accountType = scanner.next();
						isOkAcctype = service.checkAccType(accountType);
//User friendly suggestion
						if (isOkAcctype) {
							System.out.println("Account type must be either Current or Savings\n");
						}
					} while (isOkAcctype);


					System.out.println("Enter the recipient account number : ");
					long recipientAccNo = scanner.nextLong();
					/*System.out.println("Enter the name of the recipient : ");
					String recipientname = scanner.next();
					System.out.println("Enter the IFSC code of the recipient's bank : ");
					String ifsc = scanner.next();*/
					
					System.out.println("Enter the amount to be transfered: ");
					float transferAmt = scanner.nextFloat();
//input from user is sent to map through service map
					
					float bank = service.transferAmount(accountNo, recipientAccNo, transferAmt);
					System.out.println("***********************************");
					System.out.println("  Amount transferred successfully");
					System.out.println("***********************************");

					System.out.println("YOUR UPDATED ACCOUNT DETAILS" + bank);
					System.out.println("***********************************");
						}
				
//Exception thrown for invalid account number
				catch (AccountNumberNotFoundException ae) {
					System.out.println("***********************************************");
					System.out.println("  You've entered an incorrect account number");
					System.out.println("***********************************************");
				}
//Exception thrown for different inputs
				catch (InputMismatchException ae) {
					System.out.println("Enter valid input for the given fields");
				}

				break;
			}

			case 6:
				 try{
					 service.printTransactions();
	                } catch (Exception e) {
	                    System.out.println("Enter Valid information");
	                }
	                break;
	                
			case 7:System.exit(0);
			}
		}
	}
}
