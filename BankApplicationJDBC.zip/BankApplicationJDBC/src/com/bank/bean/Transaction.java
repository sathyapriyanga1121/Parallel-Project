package com.bank.bean;

public class Transaction {
	private int transactionId;
	private long transactionAccount;
	private long toAccount;
	private float oldBalance;
	private float newBalance;
	private String transactionType;
	
//overrided toString method
	@Override
	public String toString() {
		System.out.println("==================================================");
		return "\n\n***********************\n TRANSACTION DETAILS:\n*********************** \n Transaction Id:" + transactionId + "\n Transaction Account=" + transactionAccount
				+ "\n To Account=" + toAccount + "\n Old Balance=" + oldBalance
				+ "\n New Balance=" + newBalance + "\n Transaction Type=" + transactionType + "";
	}
	
//getter setter for private data members
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	
	
	public long getTransactionAccount() {
		return transactionAccount;
	}
	public void setTransactionAccount(long transactionAccount) {
		this.transactionAccount = transactionAccount;
	}
	
	
	public long getToAccount() {
		return toAccount;
	}
	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}
	
	
	
	public float getOldBalance() {
		return oldBalance;
	}
	public void setOldBalance(float oldBalance) {
		this.oldBalance = oldBalance;
	}
	
	
	public float getNewBalance() {
		return newBalance;
	}
	public void setNewBalance(float newBalance) {
		this.newBalance = newBalance;
	}
	
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactiontype) {
		this.transactionType = transactiontype;
	}

}
