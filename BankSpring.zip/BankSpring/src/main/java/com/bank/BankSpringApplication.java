package com.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankSpringApplication.class, args);
	}

}
