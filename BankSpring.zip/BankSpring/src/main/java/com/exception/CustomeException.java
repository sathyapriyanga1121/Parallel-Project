package com.exception;


public class CustomeException extends Exception {
	
	String s;

	public CustomeException(String s) {
		System.out.println(s);
	}
	
	

}
