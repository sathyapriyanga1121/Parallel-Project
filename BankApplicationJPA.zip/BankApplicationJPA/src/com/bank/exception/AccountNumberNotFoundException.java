package com.bank.exception;

public class AccountNumberNotFoundException extends RuntimeException {
	//user defined exception for invalid account number 
	private static final long serialVersionUID = 1L;

	public AccountNumberNotFoundException(final String msg){
		super(msg);
	}
	 
	}


