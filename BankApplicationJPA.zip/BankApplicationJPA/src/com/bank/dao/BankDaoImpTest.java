package com.bank.dao;

import org.junit.Assert;
import org.junit.Test;

public class BankDaoImpTest {

	BankDao dao=new BankDaoImp();

    @Test
    public void deposit(){
    	int deposit=500;
        long balance=dao.showDetails(1);
        float result=dao.depositAmount(1, deposit);
        float expectedResult=balance+deposit;
        Assert.assertEquals(expectedResult,result);
        System.out.println(expectedResult=result);
    }
    
    @Test
    public void withdraw(){
    	int withdraw=500;
        long balance=dao.showDetails(1);
        float result=dao.depositAmount(1, withdraw);
        float expectedResult=balance-withdraw;
        Assert.assertEquals(expectedResult,result);
        System.out.println(expectedResult=result);
    }
}
   /* 
    @org.junit.Test
    public void test2(){
    	int withdraw=500;BankDao dao=new

        int balance=dao.showBalance(1);
        int result=dao.withDraw(1, withdraw);
        int expectedResult=balance-500;
        assertEquals(expectedResult,result);
        System.out.println(expectedResult+"="+result);
    }
    
    @org.junit.Test
    public void test3(){
    	int fund=500;
        int balance=dao.showBalance(1);
        int result=dao.fundTransfer(1,3,fund);
        int expectedResult=balance-500;
        assertEquals(expectedResult,result);
        System.out.println(expectedResult=result);
    }
    */
    
