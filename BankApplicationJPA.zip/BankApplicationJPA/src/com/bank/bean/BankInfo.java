package com.bank.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="bankjpa")
public class BankInfo {

private long accountNo;
private String name; 
private Date dob;
private float balance;
private long mobNo;
private String accountType;
private String branch;

//overrided toString method
@Override
public String toString() {
	return " \nName=" + name + "\nAccount Balance=" + balance + "";
}

//getter setters for private data members
public long getAccountNo() {
	return accountNo;
}

public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}

public long getMobNo() {
	return mobNo;
}
public void setMobNo(long mobNo) {
	this.mobNo = mobNo;
}

public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}


public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}


}
